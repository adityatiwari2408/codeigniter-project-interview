<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->match(['get','post'],'/', 'Home::index');

$routes->match(['get','post'],'login','Home::login');
$routes->match(['get','post'],'register','Home::index');
$routes->match(['get','post'],'dashboard','Home::dashboard');
$routes->match(['get','post'],'profile','Home::profile');
$routes->match(['get','post'],'search','Home::search');

$routes->match(['get','post'],'logout','Home::logout');
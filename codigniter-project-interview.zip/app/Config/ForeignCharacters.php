<?php

namespace Config;

use CodeIgniter\Config\ForeignCharacters as BaseForeignCharacters;

/**
 * @immutable
 */
class ForeignCharacters extends BaseForeignCharacters
{
}

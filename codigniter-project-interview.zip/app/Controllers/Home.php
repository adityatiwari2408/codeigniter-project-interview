<?php

namespace App\Controllers;

class Home extends BaseController
{

  
    public function index()
    {
        $validation =  \Config\Services::validation();

        if(isset($_POST['submit'])){

            $rules=([
                'name'=>'required',
                'email' => 'required|valid_email',
                'password'=>'required|min_length[8]',
                'cpassword'=>'required|min_length[8]|matches[password]',
            ]);

            if($this->validate($rules)==true){

                 $file=$this->request->getFile('image');
                 if($file->isValid()){
                    $image=rand(2,9999).$file->getName();
                    
                    $file->move('public/upload/profile/',$image);
                 }
                 else{
                    $image='';
                 }

                
                 $password=$this->request->getPost('password');
                  $data=array(
                     'name'=>$this->request->getPost('name'),
                     'email'=>$this->request->getPost('email'),
                     'password'=>password_hash($password,PASSWORD_BCRYPT),
                     'profile'=>$image,
                  );

                  $this->model->insertdata('user',$data);

                 
            }else{
                $data['validation']=$validation->getErrors();
                return view('register',$data);
            }
            
        }
        return view('register');
    }


    public function login (){

        if(isset($_POST['submit'])){
            
            $email=$this->request->getPost('email');
            $password=$this->request->getPost('password');

            $isvalid=$this->model->fetchbycolumn('user','email',$email);
            if(count($isvalid)==1){
                 if(password_verify($password,$isvalid[0]->password)){
                    $userdata=array(
                        'id'=>$isvalid[0]->id,
                        'email'=>$isvalid[0]->email,
                        'name'=>$isvalid[0]->name,
                    );
                      $this->session->set($userdata);

                      return redirect()->to('dashboard');
                 }else{
                    $this->session->setFlashdata('message','<h5>Wrong Password</h5>');
                    return redirect()->to('login');
                 }
                 
            }else{
                $this->session->setFlashdata('message','<h5>Wrong Email</h5>');
                return redirect()->to('login');
             }
            


        }
         return view('login');
    }


    public function dashboard(){
        $id=$this->session->get('id');
        if(!empty($id)){

            $data['profiledata']=$this->model->fetchbycolumn('user','id',$id);
            return view('dashboard',$data);
        }else{
            return redirect()->to('login');
        }
        
    }


    public function logout(){
        $this->session->destroy();
        return redirect()->to('login');
    }


    public function profile(){

        $id=$this->session->get('id');
        if(isset($_POST['submit'])){
            $file=$this->request->getFile('image');
            $oldimage=$this->request->getPost('old-image');

            if($file->isValid()){
                $image=rand(2,9999).$file->getName();
                $file->move('public/upload/profile/',$image);
                $path='public/upload/profile/'.$oldimage;
                unlink($path);
            }else{
                $image=$oldimage;
            }

            $data=array(
                'name'=>$this->request->getPost('name'),
                'email'=>$this->request->getPost('email'),
                'profile'=>$image,
            );

            if(!empty($this->request->getPost('password'))){
                $data['password']=password_hash($this->request->getPost('password'),PASSWORD_BCRYPT);
            }

            $this->model->updatebycolumn('user','id',$id,$data);
            return redirect()->to('dashboard');
        }
        
        $data['profiledata']=$this->model->fetchbycolumn('user','id',$id);
        return view('user/profile',$data);
    }


    public function search(){

        if(isset($_POST['submit'])){
            $keyword=$this->request->getPost('name');

          $response = $this->do_post_curl($keyword,'GET');
        $data['images']=$response->hits;
        $data['total']=$response->total;
        $data['totalhits']= $response->totalHits;

       

           return view('search',$data);
        }

        return view('search');

    }


    public function do_post_curl($keyword,$method){

       $url='https://pixabay.com/api/?key=41066246-d99e6b666fee58684edbed79f&q='.$keyword;
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => $method,
        // CURLOPT_POSTFIELDS =>$data,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
        ),
        ));
    
    
       
        $response = curl_exec($curl);
        curl_close($curl);


      

         $imagedata=json_decode($response);

        // echo '<pre>';
        // print_r($imagedata->hits['ima']);

        // echo '</pre>';
        // // echo count($imagedata['hits']);
        // exit();

    
     
        return $imagedata;
      }
}

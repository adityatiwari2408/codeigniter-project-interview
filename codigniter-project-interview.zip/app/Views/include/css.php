<link rel="stylesheet" href="<?php echo base_url('public/assets/bootstrap/css/bootstrap.min.css');?>">
    <!-- ALL GOOGLE FONTS -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,700,800,900" rel="stylesheet">
    <!-- FONT AWESOME CSS -->
    <link rel="stylesheet" href="<?php echo base_url('public/assets/fonts/linear-fonts.css');?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- OWL CAROSEL CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>/public/assets/owlcarousel/css/owl.carousel.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/public/assets/owlcarousel/css/owl.theme.css">
    <!-- MAGNIFIC CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>/public/assets/css/magnific-popup.css">
    <!-- ANIMATE CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>/public/assets/css/animate.min.css">
    <!-- MAIN STYLE CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>/public/assets/css/style.css">
    <!-- RESPONSIVE CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>/public/assets/css/responsive.css">
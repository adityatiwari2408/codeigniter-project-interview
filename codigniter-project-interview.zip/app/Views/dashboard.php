<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <?php echo view('user/include/css');?>
</head>
<body>

   <?php echo view('user/include/header');?>
   <?php $session=session();?>



   <div class="container" style="padding-top: 50px;">

  
   


   <?php if($session->getFlashdata('message')){ echo $session->getFlashdata('message');}?>
              
          
          <div style="margin-top: 50px;">
                    <a href="<?php echo base_url('dashboard')?>" class="btn btn-primary">Dashboard</a>
                     <a href="<?php echo base_url('profile')?>" class="btn btn-primary">Profile</a>
                     <a href="<?php echo base_url('search')?>" class="btn btn-primary">Search</a>
          </div>

          <h3 style="text-align:center">Welcome <?php echo $session->get('name'); ?></h3>


          <div class="row" style='margin-top:50px'>
              <div class="col-md-6">
                <a href="<?php echo base_url('profile');?>"> <img src="<?php echo base_url('public/upload/profile/'.$profiledata[0]->profile);?>" alt="" style="height:100px;width:100px;object-fit:contain;"></a>
              </div>
              <div class="col-md-6">
                <h3>Name:<?php echo $profiledata[0]->name;?></h3>
                <h3>Email:<?php echo $profiledata[0]->email;?></h3>
               
              </div>
          </div>
    </div>


</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search</title>
    <?php echo view('user/include/css');?>
</head>
<body>

   <?php echo view('user/include/header');?>
   <?php $session=session();?>



   <div class="container" style="padding-top: 50px;">

   <h5>Welcome <?php echo $session->get('name'); ?></h5>

   
   


   <?php if($session->getFlashdata('message')){ echo $session->getFlashdata('message');}?>
              
          
          <div>
                    <a href="<?php echo base_url('dashboard')?>" class="btn btn-primary">Dashboard</a>
                     <a href="<?php echo base_url('profile')?>" class="btn btn-primary">Profile</a>
                     <a href="<?php echo base_url('search')?>" class="btn btn-primary">Search</a>
          </div>
    </div>

    <div class="container" style="padding-top: 50px;">
        <form class="form px-2 py-5" method="post" enctype="multipart/form-data">
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Search </label>
            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Search" name="name" required >
           
          </div>
         
          <button class="btn btn-primary" type="submit" name="submit">submit</button>
          </form>
          </div>


          <?php if(!empty($total) && !empty($totalhits)){?>
             <h5 style='text-align:center'>We Found <?php echo count($images);;?>&nbsp;out of <?php echo $total;?></h5>
          <?php }?>
         
          <div class="row" style="margin-top:50px">
          <?php if(isset($images)){?>
          
               <?php foreach($images as $data){?>
                <div class="col-md-4" style="margin-top: 20px;">

                   <a href="<?php echo $data->largeImageURL	;?>" target="_blank"><img src="<?php echo $data->largeImageURL	;?>" alt="pixabayimages" style="height:400px;width:100%;object-fit:cover;"></a>
                </div>
                <?php } ?>
        <?php } ?>
          </div>
          
</body>
</html>
<?php
 $session=session();

 if(!$session->get('id')){
    return redirect()->to('login');
 }

?>


<header id="home" class="welcome-area">
        <div class="header-top-area" style="padding:10px 0px; background:#000; color:aliceblue ;font-size:20px;">
            <div class="container" >
                <div class="row" style="display:flex;justify-content:space-around">
                   <h5>Welcome to Codeigniter Project</h5>
                   <div style="float:right">
                   <?php $session=session();?>

                    <?php if(!$session->get('id')){?>
                     <a href="<?php echo base_url('login')?>" class="btn btn-primary">Login</a>
                     <a href="<?php echo base_url('register')?>" class="btn btn-primary">Register</a>
                     <?php }else{?>
                        <a href="<?php echo base_url('logout')?>" class="btn btn-primary">Logout</a>
                        <?php } ?>
                </div>
                </div> 
                      
            </div>
            </div>
        </div>
    </header>
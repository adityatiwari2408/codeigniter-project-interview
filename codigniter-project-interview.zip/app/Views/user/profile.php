<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <?php echo view('user/include/css');?>
</head>
<body>

   <?php echo view('user/include/header');?>
   <?php $session=session();?>



   <div class="container" style="padding-top: 50px;">

   <h5>Welcome <?php echo $session->get('name'); ?></h5>

   
   


   <?php if($session->getFlashdata('message')){ echo $session->getFlashdata('message');}?>
              
          
          <div>
                    <a href="<?php echo base_url('dashboard')?>" class="btn btn-primary">Dashboard</a>
                     <a href="<?php echo base_url('profile')?>" class="btn btn-primary">Profile</a>
                     <a href="<?php echo base_url('search')?>" class="btn btn-primary">Search</a>
          </div>


          <div class="row" style='margin-top:50px'>
              <div class="col-md-6">
                 <img src="<?php echo base_url('public/upload/profile/'.$profiledata[0]->profile);?>" alt="" style="height:100px;width:100px;object-fit:contain;">
              </div>
              <div class="col-md-6">
                <h3>Name:<?php echo $profiledata[0]->name;?></h3>
                <h3>Email:<?php echo $profiledata[0]->email;?></h3>
               
              </div>
          </div>
    </div>

    <div class="container" style="padding-top: 50px;">
        <form class="form px-2 py-5" method="post" enctype="multipart/form-data">
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Name</label>
            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Name" name="name" required value="<?php echo $profiledata[0]->name;?>">
           
          </div>
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Email</label>
          <input type="text" name="email" class="form-control" id="exampleFormControlInput1" placeholder="Email" required value="<?php echo $profiledata[0]->email;?>">
         
          </div>
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">New Password</label>
          <input type="password" name="password" class="form-control" id="exampleFormControlInput1" placeholder="Password " >
         
          </div>

          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Profile Image</label>
            <input type="hidden" name="old-image" value="<?php echo $profiledata[0]->profile;?>">
          <input type="file" name="image" class="form-control" id="exampleFormControlInput1" placeholder="book id " >
          </div>

          <button class="btn btn-primary" type="submit" name="submit">submit</button>
          <button class="btn btn-danger" type="reset">Cancel</button>
          </form>
          </div>
</body>
</html>
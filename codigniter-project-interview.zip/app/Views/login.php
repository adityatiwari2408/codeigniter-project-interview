<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <?php echo view('include/css');?>
</head>
<body>

   <?php echo view('include/header');?>



   <div class="container" style="padding-top: 50px;">
   <?php $session=session();?>

   <?php if($session->getFlashdata('message')){ echo $session->getFlashdata('message');}?>
        <form class="form px-2 py-5" method="post" enctype="multipart/form-data">
         
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Email</label>
          <input type="text" name="email" class="form-control" id="exampleFormControlInput1" placeholder="Email" required>
          <?php if(isset($validation['email'])){ echo $validation['email'];}?>
          </div>
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Password</label>
          <input type="password" name="password" class="form-control" id="exampleFormControlInput1" placeholder="Password " required>
          <?php if(isset($validation['password'])){ echo $validation['password'];}?>
          </div>

          <button class="btn btn-primary" type="submit" name="submit">submit</button>
          <button class="btn btn-danger" type="reset">Cancel</button>
          </form>
          </div>
    </div>
</body>
</html>
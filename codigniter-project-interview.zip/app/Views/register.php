<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <?php echo view('include/css');?>
</head>
<body>

   <?php echo view('include/header');?>



   <div class="container" style="padding-top: 50px;">
        <form class="form px-2 py-5" method="post" enctype="multipart/form-data">
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Name</label>
            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Name" name="name" required>
            <?php if(isset($validation['name'])){ echo $validation['name'];}?>
          </div>
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Email</label>
          <input type="text" name="email" class="form-control" id="exampleFormControlInput1" placeholder="Email" required>
          <?php if(isset($validation['email'])){ echo $validation['email'];}?>
          </div>
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Password</label>
          <input type="password" name="password" class="form-control" id="exampleFormControlInput1" placeholder="Password " required>
          <?php if(isset($validation['password'])){ echo $validation['password'];}?>
          </div>
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Confirm Password</label>
          <input type="password" name="cpassword" class="form-control" id="exampleFormControlInput1" placeholder="Confirm Password" required>
          <?php if(isset($validation['cpassword'])){ echo $validation['cpassword'];}?>
          </div>

          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Profile Image</label>
          <input type="file" name="image" class="form-control" id="exampleFormControlInput1" placeholder="book id " required>
          </div>

          <button class="btn btn-primary" type="submit" name="submit">submit</button>
          <button class="btn btn-danger" type="reset">Cancel</button>
          </form>
          </div>
    </div>
</body>
</html>
<?php

namespace App\Models;
use CodeIgniter\Model;


class Crud extends Model{


    public function insertdata($table,$data){
        $this->db->table($table)->insert($data);
    }

    public function fetchbycolumn($table,$column,$value){
       $data= $this->db->table($table)->where($column,$value)->get();
        return $data->getResult();
    }

    public function updatebycolumn($table,$column,$value,$data){
        $this->db->table($table)->where($column,$value)->update($data);
    }
}




?>